
/**Task9 */

var logOne = setTimeout(function () {

    console.log("one!");

}, Math.random() * 1000);

var logTwo = setTimeout(function () {

    console.log("two!");

}, Math.random() * 1000);


function inOrderPromises(fn1, fn2) {
    () => fn1.then( () => fn2)
}

//By Call backs

const inOrder = (fn1, fn2) => {
    if (fn1) {
        ()=>fn1.then(()=>{
            if (fn2) {
                fn2
            } else {
                throw("arguments must be a function");
            }
        })
    } else {
        throw("arguments must be a function");
    }
}

inOrder(logOne,logTwo)
inOrderPromises(logOne, logTwo);


//StarWars API call

function getCrawls(data){

    data.forEach((movie,index)=>{
        console.log("Movie: "+movie.title+"\n----------------------")
        console.log(movie.opening_crawl)
        console.log("\n-------------------")
        
    })
}

function getPlanets(data){

    data.forEach((movie,ind)=>{

        console.log(movie.planets)
    })
}

$.ajax({
    url: 'https://swapi.dev/api/films/',
    method:'GET',
    dataType:'json',
    success:function(data){
        getCrawls(data.results)
        
        //Make another ajax call to get planets for each movie
        $.ajax({
            url: 'https://swapi.dev/api/films/',
            method:'GET',
            dataType:'json',
            success:function(data){
                getPlanets(data.results)
                
            },                
            error: function(err){
                console.log(err)
            }
        })
    },                
    error: function(err){
        console.log(err)
    }
})



//Implementing Promise.all
//Get user information whose id is given
function getUsers(id){

    return $.getJSON('https://randomuser.me/api?id='+id)
}

Promise.all([getUsers(1),getUsers(2),getUsers(3)]).then((data)=>{console.log(data)}).catch((error)=>{console.log(error)})