function createAnimal(species,verb,noise){


    //Create a function, that will be associated with object and return object

    let animal={
        species:species,
        verb:verb,
        [verb]: ()=>{
            console.log(noise)
        }
    }
    return animal;
}

let dog=createAnimal('dog','bark','Woooof')
dog.bark()

let sheep=createAnimal('Sheep','bleet','BAAAAaaaa')
sheep.bleet()