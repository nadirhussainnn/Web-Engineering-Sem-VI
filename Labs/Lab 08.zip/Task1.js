
let raceResults=(array)=>{
    const[first,second, ...rest]=array
    let obj={
        first:first,
        second:second,
        rest:rest
    }
    return obj
}

console.log(raceResults(['Tom','Margaret','Allison','David','Pierre']));