
async function loadJson(url) {
    
    
    let response= await fetch(url)
    
    if(response.ok){
        let data=await response.json()
        console.log(data)
    }
    else{
        throw new Error(response.status);
    }
}

loadJson('http://www.maciejtreder.com/asynchronous-javascript/directors/')